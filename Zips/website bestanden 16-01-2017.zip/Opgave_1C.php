<?php

// Maak een functie GeefDeelbareArray($array, $deler)
//
// Eigenlijk moet deze functie vergelijkbare foutcontroles hebben
// als de functie in de vorige deelopgave. We kiezen er hier voor
// om deze controles niet opnieuw te implementeren: We laten ze
// zelfs gewoon helemaal weg.
//
// Alle elementen uit $array worden onderzocht of zij deelbaar zijn
// door $deler, dus met rest 0. We gebruiken hiervoor het PHP commando
// fmod. Alle elementen die deelbaar zijn met rest 0 worden aan de
// resultaat array toegevoegd en geretourneerd.


function GeefDeelbareArray($array, $deler) {
    // We doen nu geen foutcontroles: zou eigenlijk wel moeten

    $resultaatArray = array();

    // % operator is handiger dan fmod
    foreach ($array as $waarde) {
        $rest = fmod($waarde, $deler);
        $deelbaar = ($rest <= 0.00001); // tricky ivm float
        if ($deelbaar) {
            array_push($resultaatArray, $waarde);
        }
    }

    return $resultaatArray;
}

function GeefDeelbareArray2($array, $deler) {
    // We doen nu geen foutcontroles: zou eigenlijk wel moeten

    $resultaatIndex = 0;
    $resultaatArray = array();

    // nu met % operator
    foreach ($array as $waarde) {
        $deelbaar = ($waarde % $deler == 0);
        if ($deelbaar) {
            $resultaatArray[$resultaatIndex] = $waarde;
            $resultaatIndex++;
        }
    }

    return $resultaatArray;
}

// Merk op: functie ZONDER return waarde! (void)
function toonArray($toelichting, $array){
    echo "<br><br>$toelichting:<br><br>";   //Merk op: variabele evaluatie!
    foreach ($array as $waarde)
    {
        echo $waarde . "<br>";
    }
}

$getallen = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ];


toonArray("Geef de elementen die deelbaar zijn door 1", GeefDeelbareArray($getallen, 1));
toonArray("Geef de elementen die deelbaar zijn door 2", GeefDeelbareArray($getallen, 2));
toonArray("Geef de elementen die deelbaar zijn door 3", GeefDeelbareArray($getallen, 3));
toonArray("Geef de elementen die deelbaar zijn door 5", GeefDeelbareArray($getallen, 5));
toonArray("Geef de elementen die deelbaar zijn door 10", GeefDeelbareArray($getallen, 10));

/*
toonArray("Geef de elementen die deelbaar zijn door 1", GeefDeelbareArray2($getallen, 1));
toonArray("Geef de elementen die deelbaar zijn door 2", GeefDeelbareArray2($getallen, 2));
toonArray("Geef de elementen die deelbaar zijn door 3", GeefDeelbareArray2($getallen, 3));
toonArray("Geef de elementen die deelbaar zijn door 5", GeefDeelbareArray2($getallen, 5));
toonArray("Geef de elementen die deelbaar zijn door 7", GeefDeelbareArray2($getallen, 7));
toonArray("Geef de elementen die deelbaar zijn door 10", GeefDeelbareArray2($getallen, 10));
*/