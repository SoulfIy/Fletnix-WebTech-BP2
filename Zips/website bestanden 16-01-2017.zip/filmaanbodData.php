<div class="filmaanbod">

    <div class="actualiteiten">

        <div class="actualiteitentekst">

            <h1>Welkom terug, [GEBRUIKER]</h1>

            <div class="button">
                <button type="button" class="mainbuttondeco" onclick="location.href='abonnementskeuze.php'">Zoeken</button>
            </div>
        </div>

    </div>

    <div class="aanbod">

        <div class="lijst">
            <h2>Mijn lijstje</h2>

            <img class="movieposter" src="css/images/matrixPoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/exorcistPoster.jpeg" alt="movieposter">
            <img class="movieposter" src="css/images/groundhogdayPoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/spongebobmoviePoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/zohanPoster.jpg" alt="movieposter">
        </div>

        <div class="lijst">
            <h2>Populaire films en series</h2>

            <img class="movieposter" src="css/images/matrixPoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/exorcistPoster.jpeg" alt="movieposter">
            <img class="movieposter" src="css/images/groundhogdayPoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/spongebobmoviePoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/zohanPoster.jpg" alt="movieposter">
        </div>

        <div class="lijst">
            <h2>Nieuwe films en series</h2>

            <img class="movieposter" src="css/images/zohanPoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/matrixPoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/spongebobmoviePoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/exorcistPoster.jpeg" alt="movieposter">
            <img class="movieposter" src="css/images/groundhogdayPoster.jpg" alt="movieposter">
        </div>

        <div class="lijst">
            <h2>Top 10</h2>

            <img class="movieposter" src="css/images/matrixPoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/exorcistPoster.jpeg" alt="movieposter">
            <img class="movieposter" src="css/images/groundhogdayPoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/spongebobmoviePoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/zohanPoster.jpg" alt="movieposter">
        </div>

    </div>


</div>