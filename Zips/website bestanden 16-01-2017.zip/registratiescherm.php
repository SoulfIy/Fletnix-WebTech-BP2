<?php
session_start();

require_once 'fletnix-util.php';

connectToDatabase();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300|Roboto" rel="stylesheet">
    <title>Homepagina</title>
</head>
<body>

<?php require 'header.html'; ?>


<br><br><br><br><br>


<div class="registratieform">

    <form name="registratieform" method="post">
        <input title="naam" type="text" name="name" placeholder="name">
        <input title="email" type="email" name="email" placeholder="email">
        <input title="password" type="password" name="password" placeholder="password">
        <input title="paypal_account" type="text" name="paypal_account" placeholder="paypal_account">
        <input type="submit" name="register" onclick="alert('wachtwoord en username verzonden')">
    </form>

</div>

<?php
//$password = $_POST['register']['password'];
print_r($_POST);
?>

<select>
<?php
    $landenlijst[] = getLanden();

    for ($i = 0; $i < count($landenlijst[0]); $i++) {
        echo '<option value="'.$landenlijst[0][$i].'">'.$landenlijst[0][$i].'</option>';
    }
    ?>
</select>

<?php require 'footer.html'; ?>

</body>
</html>