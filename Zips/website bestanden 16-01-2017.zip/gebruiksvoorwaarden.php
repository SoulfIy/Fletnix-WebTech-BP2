<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300|Roboto" rel="stylesheet">
    <title>Homepagina</title>
</head>
<body>

<?php require 'header.html'; ?>

<div class="gebruiksvoorwaarden">

    <h2>Gebruiksvoorwaarden</h2>

    <ol>

        <li><p>Bij het gebruik maken van deze service ("Fletnix") gaat u ermee akkoord dat wij uw<br>
        gebruiksgegevens kunnen gebruiken bij en voor het verbeteren van de service ("Fletnix"). Ook<br>
        ...</p></li>

        <li><p>en daarna ...</p>

        </li>

    </ol>

</div>

<?php require 'footer.html'; ?>

</body>
</html>