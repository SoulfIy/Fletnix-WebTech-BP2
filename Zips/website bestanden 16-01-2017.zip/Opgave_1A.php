<?php

require 'fletnix-util.php';

connectToDatabase();
print_r (getLanden());

$getallen = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 ];

// Schijf code waarmee alle getallen uit $getallen onder
// elkaar afgedrukt worden.
// Doe dit met:
//          - for loop
//          - while loop
//          - foreach loop

for ($i = 0; $i < count($getallen); $i++) {
    echo $getallen[$i].'<br>';
    isHetEinde($getallen[$i], $getallen);
}

$teller = 0;
while ( $teller < count($getallen)) {
    echo $getallen[$teller].'<br>';
    isHetEinde($getallen[$teller], $getallen);
    $teller++;
}

foreach ($getallen as $huidigeGetal) {
    echo $huidigeGetal .'<br>';
    isHetEinde($huidigeGetal, $getallen);
}

function isHetEinde($getal, $arrayMax) {
    $textStyle = [ '<em>', '<b>', '</em>', '</b>'];

    if ($getal == count($arrayMax)) {
        echo '<br>';
    }
}


?>
















// for loop:
echo "Met behulp van for loop:<br><br>";

for ($teller = 0; $teller < count($getallen); $teller++) {
    echo $getallen[$teller] . "<br>";
}

// while loop:
echo "<br><br>Met behulp van while loop:<br><br>";

$teller = 0;
$maxCount = count($getallen);

while ($teller < $maxCount) {
    echo $getallen[$teller] . "<br>";
    $teller++;
}

// foreach loop:
echo "<br><br>Met behulp van foreach loop:<br><br>";

foreach ($getallen as $huidigeGetal) {
    echo $huidigeGetal ."<br>";
}

// Let ook op de HTML: <br> in dit geval.
//
// Dit wordt tijdens de toets erg streng meegewogen in
// de beoordeling!!!
