<?php

// Gegeven is een multidimensionele array die bovendien diverse datatypen bevat.
//
// Het doel is om de functie toonTafel($tafel) te maken.
//
// De titel ("Tafel van 3") moet uit de array gehaald worden en in een H1 tag getoond worden.
// De sommen van de tafel zijn netjes leesbaar uitgewerkt zoals we dat op de basisschool
// geleerd hebben. De uitkomst is extra belangrijk daarom omringen we deze met een span met
// class "uitkomst". Met wat extra CSS kan dit dan makkelijk een andere uiterlijk krijgen
// (mag je doen als extra oefening).

$tafelVan3 = array(
    array("Tafel van 3", 1, 4, 4),
    array("Tafel van 3", 2, 4, 8),
    array("Tafel van 3", 3, 4, 12),
    array("Tafel van 3", 4, 4, 16),
    array("Tafel van 3", 5, 4, 20),
    array("Tafel van 3", 6, 4, 24),
    array("Tafel van 3", 7, 4, 28),
    array("Tafel van 3", 8, 4, 32),
    array("Tafel van 3", 9, 4, 36),
    array("Tafel van 3", 10, 4, 40)
);

function toonTafel($tafel) {
    // We nemen aan dat de invoer correct is, dus we laten
    // foutcontrole achterwege (mag natuurlijk niet in
    // productiecode!!!)

    // Definieer een aantal constantes (SPD: GEEN magische getallen!!!)
    define("KOLOM_TITEL", 0);
    define("KOLOM_TELLER", 1);
    define("KOLOM_TAFEL", 2);
    define("KOLOM_UITKOMST", 3);
    define("RIJ_EERSTE", 0);

    $titel = $tafel[RIJ_EERSTE][KOLOM_TITEL];
    echo "<h1>$titel</h1>";     //Hoe wordt de layout bepaald?

    $rijTellerMax = count($tafel);

    for ($rijTeller = 0; $rijTeller < $rijTellerMax; $rijTeller++) {
        $teller = $tafel[$rijTeller][KOLOM_TELLER];
        $tafelWaarde = $tafel[$rijTeller][KOLOM_TAFEL];
        $uitkomst = $tafel[$rijTeller][KOLOM_UITKOMST];
        echo "$teller x $tafelWaarde = <span class=\"uitkomst\">$uitkomst</span><br>";
    }
}

toonTafel($tafelVan3);