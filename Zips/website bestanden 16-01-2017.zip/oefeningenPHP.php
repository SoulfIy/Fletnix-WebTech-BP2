<?php
$abc = 5;
$def = 7;

$lijst[] = array(5, 2, 5, 2);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300|Roboto" rel="stylesheet">
    <title>Homepagina</title>
</head>
<body>

<?php
echo $abc + $def;

for ($i = 0; $i < 5; $i++) {
    echo $abc + $def + $i;
}

foreach ($lijst as $value) {
    echo $lijst[$lijst];
}

?>

</body>
</html>

