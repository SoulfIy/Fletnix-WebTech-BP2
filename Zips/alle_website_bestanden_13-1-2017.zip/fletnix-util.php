<?php
connectToDatabase();

$ingelogd = false;

function connectToDatabase() {
global $pdo;

$pdo = new PDO("sqlsrv:Server=localhost;Database=CASUS_FLETNIX", "sa", "password123");
}

function getNames(){
    global $pdo;
    $names = array();

    $data = $pdo->query("SELECT * FROM person");
    while ($row = $data->fetch()){
        $names[$row["afkorting"]]= array($row["voornaam"], $row["achternaam"]);
    }

    return $names;
}

function getIngevoerdeInlogGegevens() {
    $maxAantal = count(getPersoonsGegevens());
    $arrayGegevens = getPersoonsGegevens();

    if (isset($_POST['login'])) {

        if (isset ($_POST['email']['password'])) {

            for ($i = 0; $i < $maxAantal; $i++) {

                if ($_POST['email']['password'] == $arrayGegevens[$i][0] ) {

                    $_SESSION = $_POST['email'];
                    $ingelogd = true;
                }
                else $ingelogd = false;
            }
        }
    }
}



function getPersoonsGegevens() {
    global $pdo;
    $persoonsGegevens = array();

    $data = $pdo->query("SELECT customer_mail_address, password FROM customer");
    while ($row = $data->fetch()) {
        $persoonsGegevens[$row["customer_mail_address"]] = array($row["password"]);
    }
    return $persoonsGegevens;
}


function getZoekGegevens() {
    global $pdo;
    $zoekGegevens = array();

    $data = $pdo->query("SELECT title, password FROM movie");
    while ($row = $data->fetch()) {
        $zoekGegevens[$row["customer_mail_address"]] = array($row["password"]);
    }
    return $zoekGegevens;
}

//print_r(getLanden());
function getLanden() {
    global $pdo;
    $landGegevens = array();

    $data = $pdo->query("SELECT country_name FROM country");
    while ($row = $data->fetch()) {
        $landGegevens[] = $row["country_name"];
    }

    return $landGegevens;
}

function addUser() {
    global $pdo;

    $customer_mail_address = $_POST['email'];
    $name = $_POST['name'];
    $paypal_account = $_POST['paypal_account'];
    $password = $_POST['password'];
    $country_name = $_POST['country_name'];

    if (invoerIsGoed()) {
        $pdo->query("INSERT INTO customer (customer_mail_address, name, paypal_account, password, country_name) 
              values ($customer_mail_address, $name, $paypal_account, $password, $country_name)");
    }
}
?>