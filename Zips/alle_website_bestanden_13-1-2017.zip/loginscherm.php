<?php
session_start();
require_once 'db-fletnix.php';
require_once 'fletnix-util.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300|Roboto" rel="stylesheet">
    <title>Homepagina</title>
</head>
<body>

<?php require 'header.html'; ?>

<div class="loginform">
    <form method="post">
        <input title="username" type="text" name="email" placeholder="email">
       <input title="password" type="password" name="password" placeholder="password">
       <input type="submit" name="login" onclick="alert('wachtwoord en username verzonden')">
    </form>
    <?
    if (isset ($_POST['login'])) {
        getIngevoerdeInlogGegevens();
        echo 'woop';
    } else {
        echo 'verkeerde gegevens';
    }

    ?>
</div>

<?php require 'footer.html'; ?>

</body>
</html>
