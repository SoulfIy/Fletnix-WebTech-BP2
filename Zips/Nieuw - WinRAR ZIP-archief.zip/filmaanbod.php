<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300|Roboto" rel="stylesheet">
    <title>Homepagina</title>
</head>
<body>

<?php require 'header.html'; ?>

<div class="filmaanbod">

    <div class="actualiteiten">

        <h1>Welkom terug, [GEBRUIKER]</h1>

        <div class="button">
            <button type="button" class="mainbuttondeco" onclick="location.href='abonnementskeuze.php'">Zoeken</button>
        </div>

    </div>

    <div class="aanbod">

        <div class="mijnlijstje">
            <h2>» Mijn lijstje «</h2>

            <img class="movieposter" src="css/images/matrixPoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/exorcistPoster.jpeg" alt="movieposter">
            <img class="movieposter" src="css/images/groundhogdayPoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/spongebobmoviePoster.jpg" alt="movieposter">
            <img class="movieposter" src="css/images/zohanPoster.jpg" alt="movieposter">
        </div>

        <div class="populaire">
        <h2>» Populaire films en series «</h2>

        <img class="movieposter" src="css/images/matrixPoster.jpg" alt="movieposter">
        <img class="movieposter" src="css/images/exorcistPoster.jpeg" alt="movieposter">
        <img class="movieposter" src="css/images/groundhogdayPoster.jpg" alt="movieposter">
        <img class="movieposter" src="css/images/spongebobmoviePoster.jpg" alt="movieposter">
        <img class="movieposter" src="css/images/zohanPoster.jpg" alt="movieposter">
        </div>

        <div class="nieuwe">
        <h2>» Nieuwe films en series «</h2>

        <img class="movieposter" src="css/images/zohanPoster.jpg" alt="movieposter">
        <img class="movieposter" src="css/images/matrixPoster.jpg" alt="movieposter">
        <img class="movieposter" src="css/images/spongebobmoviePoster.jpg" alt="movieposter">
        <img class="movieposter" src="css/images/exorcistPoster.jpeg" alt="movieposter">
        <img class="movieposter" src="css/images/groundhogdayPoster.jpg" alt="movieposter">
        </div>

        <div class="top10">
        <h2>» Top 10 «</h2>

        <img class="movieposter" src="css/images/matrixPoster.jpg" alt="movieposter">
        <img class="movieposter" src="css/images/exorcistPoster.jpeg" alt="movieposter">
        <img class="movieposter" src="css/images/groundhogdayPoster.jpg" alt="movieposter">
        <img class="movieposter" src="css/images/spongebobmoviePoster.jpg" alt="movieposter">
        <img class="movieposter" src="css/images/zohanPoster.jpg" alt="movieposter">
        </div>

    </div>


</div>

<?php require 'footer.html'; ?>

</body>
</html>
